<div class="panel panel-info">
    <div class="panel-body ">
        <div class="widget-icon">
            <i class="fa fa-clock-o"></i>
        </div>
        <div class="widget-details">
            <h1><?php echo $members_clocked_in; ?></h1>
            <?php echo lang("members_clocked_in"); ?>
        </div>
    </div>
</div>