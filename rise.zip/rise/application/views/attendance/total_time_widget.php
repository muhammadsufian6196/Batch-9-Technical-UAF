<div class="box b-t">
    <div class="box-content widget-container b-r">
        <div class="panel-body ">
            <h1><?php echo $total_hours_worked; ?></h1>
            <span class="text-off uppercase"><?php echo lang("total_hours_worked"); ?></span>
        </div>
    </div>
    <div class="box-content widget-container">
        <div class="panel-body ">
            <h1 class=""><?php echo $total_project_hours; ?></h1>
            <span class="text-off uppercase"><?php echo lang("total_project_hours"); ?></span>
        </div>
    </div>
</div>